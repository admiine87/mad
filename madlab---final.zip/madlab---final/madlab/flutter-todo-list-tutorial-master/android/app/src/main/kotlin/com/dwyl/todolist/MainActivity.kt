package com.dwyl.todolist

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
