import 'package:flutter/material.dart';
import 'package:todolist/screens/tasks/tasks.dart';

void main() {
  return runApp(MaterialApp(title: 'TodoList', home: Tasks()));
}
