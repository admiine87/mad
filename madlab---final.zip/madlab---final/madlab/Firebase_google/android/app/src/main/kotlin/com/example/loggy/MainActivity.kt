package com.example.loggy

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
